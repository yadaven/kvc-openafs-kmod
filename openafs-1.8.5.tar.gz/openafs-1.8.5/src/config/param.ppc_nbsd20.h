#ifndef	AFS_PPC_PARAM_H
#define	AFS_PPC_PARAM_H

#define SYS_NAME       "macppc_nbsd20"
#define SYS_NAME_ID    SYS_NAME_ID_macppc_nbsd20

#define AFS_PPC_ENV 1
#define AFSBIG_ENDIAN   1

#endif /* AFS_PCC_PARAM_H */
