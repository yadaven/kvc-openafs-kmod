* ****NOTICE:
this file has been renamed from uvenus.h to venus.h.
    Please make any further changes to config / venus.h. * *******
