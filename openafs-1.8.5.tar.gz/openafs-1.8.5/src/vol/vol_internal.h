#ifndef AFS_SRC_VOL_INTERNAL_H
#define AFS_SRC_VOL_INTERNAL_H

/* physio.c */
extern void SetSalvageDirHandle(DirHandle *, VolumeId, Device, Inode,
                                int *);

#endif
