//
//  main.m
//  test
//
//  Created by Claudio Bisegni on 29/07/09.
//  Copyright Infn 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
